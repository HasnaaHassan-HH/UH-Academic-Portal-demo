/**
 * mark-form.js - enter or edit a mark.
 *
 * Built for fast, repeated entry:
 *  - the module, assessment and attempt are remembered between marks;
 *  - typing a student number shows the student's name, so the user can
 *    check it without leaving the page (recognition over recall);
 *  - "Save and enter next" keeps the user on the form with focus back on
 *    the student number, ready for the next script in the pile.
 */

import { api } from './api.js';
import {
  $, el, initPage, setStatus, setFlash, showError, clearMessages, classify, isPass, capitalise
} from './common.js';
import {
  showErrors, clearErrors, clearErrorsOnInput, clearFieldError, setFieldError,
  setBusy, isBusy, fieldId
} from './forms.js';

const STUDENT_NO_PATTERN = /^S\d{6}$/;
const WHOLE_NUMBER_PATTERN = /^\d+$/;
const LAST_USED_KEY = 'examOffice.lastAssessment';

const user = initPage();
const form = $('#mark-form');
const moduleSelect = $('#module');
const assessmentSelect = $('#assessment-id');
const studentInput = $('#student-no');
const lookup = $('#student-lookup');
const markInput = $('#mark');
const lateBox = $('#late');
const lateDaysInput = $('#late-days');
const preview = $('#mark-preview');
const params = new URLSearchParams(window.location.search);
const editId = params.get('id');

let reference = { modules: [], absenceReasons: [], passMark: 40, maxLateDays: 5 };
/** The student found for the number currently typed in, if any. */
let currentStudent = null;
let savedCount = 0;

/* ---------- Dependent fields ---------- */

/** Fill the Assessment list with the chosen module's assessments. */
function fillAssessments(selectedId = '') {
  const module = reference.modules.find((item) => item.code === moduleSelect.value);
  const options = module ? module.assessments : [];
  assessmentSelect.replaceChildren(
    el('option', { value: '' }, 'Select an assessment'),
    ...options.map((item) => el('option', { value: String(item.id) }, item.title))
  );
  // A module with a single assessment needs no second choice.
  assessmentSelect.value = options.length === 1 ? String(options[0].id) : String(selectedId);
}

/** Show only the fields that apply to the chosen outcome. */
function toggleSections() {
  const outcome = form.elements.outcome.value;
  $('#submitted-section').hidden = outcome !== 'submitted';
  $('#absent-section').hidden = outcome !== 'absent';
  $('#late-section').hidden = !lateBox.checked;
}

/**
 * Show the mark that will be recorded, including the late cap, before the
 * user saves. It is linked to the Mark field with aria-describedby, so it is
 * read with the field instead of interrupting typing.
 */
function updatePreview() {
  const text = markInput.value.trim();
  if (!WHOLE_NUMBER_PATTERN.test(text) || Number(text) > 100) {
    preview.textContent = '';
    return;
  }
  const mark = Number(text);
  const capped = lateBox.checked && mark > reference.passMark;
  const finalMark = capped ? reference.passMark : mark;
  const result = isPass(finalMark) ? `pass, ${classify(finalMark)}` : 'fail';
  preview.textContent = `Mark to be recorded: ${finalMark} (${result}).`
    + (capped ? ` Capped from ${mark} because the work was late.` : '');
}

/* ---------- Student look-up ---------- */

/**
 * Find the student for the typed number and show their name.
 * @returns {Promise<boolean>} true when a student was found.
 */
async function lookUpStudent() {
  const studentNo = studentInput.value.trim().toUpperCase();
  studentInput.value = studentNo;
  currentStudent = null;
  lookup.textContent = '';

  if (!STUDENT_NO_PATTERN.test(studentNo)) {
    return false;
  }

  lookup.textContent = 'Looking up student…';
  try {
    const student = await api(`/students/by-number/${studentNo}`);
    currentStudent = student;
    clearFieldError(studentInput);
    lookup.replaceChildren(
      el('span', { 'aria-hidden': 'true' }, '✓ '),
      `${student.first_name} ${student.last_name}, ${student.programme}, year ${student.year}.`,
      // Warn (in words) if the student is not currently active.
      student.status === 'active' ? '' : ` Note: this student's status is ${capitalise(student.status)}.`
    );
    return true;
  } catch (error) {
    lookup.textContent = '';
    setFieldError('student-no', error.data.notFound
      ? `No student found with number ${studentNo}. Check the number and try again.`
      : error.message);
    return false;
  }
}

/* ---------- Reading, filling and checking the form ---------- */

function readForm() {
  const data = new FormData(form);
  return {
    student_no: studentInput.value.trim().toUpperCase(),
    assessment_id: assessmentSelect.value,
    attempt: data.get('attempt'),
    outcome: data.get('outcome'),
    mark: markInput.value.trim(),
    late: lateBox.checked,
    late_days: lateDaysInput.value.trim(),
    absence_reason: $('#absence-reason').value,
    moderated: $('#moderated').checked,
    comment: $('#comment').value.trim(),
    entered_by: user.name
  };
}

function fillForm(mark) {
  moduleSelect.value = mark.module_code;
  fillAssessments(mark.assessment_id);
  form.elements.attempt.value = mark.attempt;
  studentInput.value = mark.student_no;
  form.elements.outcome.value = mark.outcome;
  markInput.value = mark.mark === null ? '' : String(mark.mark);
  lateBox.checked = mark.late_days > 0;
  lateDaysInput.value = mark.late_days > 0 ? String(mark.late_days) : '';
  $('#absence-reason').value = mark.absence_reason || '';
  $('#moderated').checked = Boolean(mark.moderated);
  $('#comment').value = mark.comment;
  toggleSections();
  updatePreview();
}

/** @returns {Object<string, string>} Map of field id -> message. */
function validate(values) {
  const errors = {};
  if (!moduleSelect.value) {
    errors.module = 'Select a module.';
  }
  if (!values.assessment_id) {
    errors['assessment-id'] = 'Select an assessment.';
  }
  if (!STUDENT_NO_PATTERN.test(values.student_no)) {
    errors['student-no'] = 'Enter a student number as the letter S followed by 6 digits, for example S240123.';
  }
  if (values.outcome === 'submitted') {
    if (!WHOLE_NUMBER_PATTERN.test(values.mark) || Number(values.mark) > 100) {
      errors.mark = 'Enter a mark as a whole number from 0 to 100.';
    }
    if (values.late && (!WHOLE_NUMBER_PATTERN.test(values.late_days)
        || Number(values.late_days) < 1 || Number(values.late_days) > reference.maxLateDays)) {
      errors['late-days'] = `Enter the number of days late as a whole number from 1 to ${reference.maxLateDays}.`;
    }
  }
  if (values.outcome === 'absent' && !values.absence_reason) {
    errors['absence-reason'] = 'Select a reason for the absence.';
  }
  return errors;
}

/** Words for the confirmation message, e.g. "62 (pass)". */
function describeSaved(mark) {
  if (mark.outcome !== 'submitted') {
    return capitalise(mark.outcome);
  }
  return `${mark.final_mark} (${isPass(mark.final_mark) ? 'pass' : 'fail'})`;
}

/** Clear the per-student fields but keep the module, assessment and attempt. */
function resetForNextStudent() {
  studentInput.value = '';
  currentStudent = null;
  lookup.textContent = '';
  form.elements.outcome.value = 'submitted';
  markInput.value = '';
  lateBox.checked = false;
  lateDaysInput.value = '';
  $('#absence-reason').value = '';
  $('#moderated').checked = false;
  $('#comment').value = '';
  toggleSections();
  updatePreview();
  studentInput.focus();
}

/* ---------- Saving ---------- */

async function save(event) {
  event.preventDefault();
  // Which button was used? Pressing Enter in a field counts as the first one.
  // When editing there is only one save button.
  const button = editId ? $('#save-button') : (event.submitter || $('#save-next-button'));
  if (isBusy(button)) {
    return;
  }

  const values = readForm();
  const errors = validate(values);
  // Make sure the student exists before saving, if not already checked.
  if (!errors['student-no'] && (!currentStudent || currentStudent.student_no !== values.student_no)) {
    const found = await lookUpStudent();
    if (!found) {
      errors['student-no'] = `No student found with number ${values.student_no}. Check the number and try again.`;
    }
  }
  if (Object.keys(errors).length) {
    clearMessages();
    showErrors(form, errors);
    return;
  }

  clearErrors(form);
  setBusy(button, true, 'Saving…');
  setStatus('Saving mark…', 'info');

  try {
    const saved = await api(editId ? `/marks/${editId}` : '/marks', {
      method: editId ? 'PUT' : 'POST',
      body: values
    });
    const summary = `${saved.first_name} ${saved.last_name}, ${saved.module_code} `
      + `${saved.assessment_title}: ${describeSaved(saved)}`;

    // Remember the assessment so the next mark starts with it selected.
    sessionStorage.setItem(LAST_USED_KEY, JSON.stringify({
      module: saved.module_code, assessment_id: saved.assessment_id, attempt: saved.attempt
    }));

    if (!editId && button.value === 'next') {
      savedCount += 1;
      setBusy(button, false);
      resetForNextStudent();
      setStatus(`Mark saved for ${summary}. ${savedCount} saved in this session. Ready for the next student.`);
    } else {
      setFlash(`Mark saved for ${summary}.`);
      window.location.assign('marks.html');
    }
  } catch (error) {
    setBusy(button, false);
    clearMessages();
    const serverErrors = Object.entries(error.fields);
    if (!serverErrors.length) {
      showError(error.message);
      return;
    }
    showErrors(form, Object.fromEntries(serverErrors.map(([name, message]) => [fieldId(name), message])));
    // A mark already exists: offer a direct route to fix it (error recovery).
    if (error.data.existingId) {
      $('.error-summary ul', form).append(el('li', {},
        el('a', { href: `mark-form.html?id=${error.data.existingId}` }, 'Open the existing mark to edit it')));
    }
  }
}

/* ---------- Start-up ---------- */

async function start() {
  try {
    reference = await api('/reference');
    moduleSelect.append(...reference.modules.map(
      (module) => el('option', { value: module.code }, `${module.code} ${module.title}`)
    ));
    $('#absence-reason').append(...reference.absenceReasons.map(
      (reason) => el('option', { value: reason.value }, reason.label)
    ));

    if (editId) {
      setStatus('Loading mark…', 'info');
      const mark = await api(`/marks/${editId}`);
      fillForm(mark);
      await lookUpStudent();
      $('#form-title').textContent = 'Edit mark';
      document.title = 'Edit mark - Exam Office Records';
      // "Save and enter next" makes no sense when correcting one mark.
      $('#save-next-button').hidden = true;
      $('#save-button').textContent = 'Save changes';
      $('#save-button').classList.remove('button--secondary');
      clearMessages();
    } else {
      // Sensible defaults: start with the assessment used last time.
      const lastUsed = JSON.parse(sessionStorage.getItem(LAST_USED_KEY) || 'null');
      if (lastUsed) {
        moduleSelect.value = lastUsed.module;
        fillAssessments(lastUsed.assessment_id);
        form.elements.attempt.value = lastUsed.attempt;
      }
      // Arriving from "Enter mark" on a student row: fill in their number.
      if (params.get('student')) {
        studentInput.value = params.get('student');
        await lookUpStudent();
      }
    }
  } catch (error) {
    showError(error.message);
  }

  moduleSelect.addEventListener('change', () => fillAssessments());
  studentInput.addEventListener('change', lookUpStudent);
  form.addEventListener('change', toggleSections);
  markInput.addEventListener('input', updatePreview);
  lateBox.addEventListener('change', updatePreview);
  clearErrorsOnInput(form);
  form.addEventListener('submit', save);
  toggleSections();
}

if (user) {
  start();
}
