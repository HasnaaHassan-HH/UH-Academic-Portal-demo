/**
 * signin.js - simulated sign-in.
 *
 * The coursework brief asks for sign-in to be simulated in JavaScript, so
 * the two demo accounts are simply listed here. A real system would check
 * credentials on the server and never keep passwords in front-end code.
 */

import { $, getUser, setUser, setStatus, clearMessages, showFlash } from './common.js';
import { showErrors, clearErrors, clearErrorsOnInput, setBusy, isBusy } from './forms.js';

const ACCOUNTS = [
  { username: 'officer', password: 'exams2026', name: 'Hasnaa Hassan', role: 'officer', roleLabel: 'Exams officer' },
  { username: 'tutor', password: 'marks2026', name: 'Sam Idowu', role: 'tutor', roleLabel: 'Module tutor' },
  { username: 'admin', password: 'mars2026', name: 'University Admin', role: 'officer', roleLabel: 'Administrator' },
  { username: 'student', password: 'mars2026', name: 'Amira Hassan', role: 'student', roleLabel: 'Student' }
];

/** Pretend the server takes a moment to answer. */
const SIGN_IN_DELAY_MS = 900;

const form = $('#signin-form');
const usernameInput = $('#username');
const passwordInput = $('#password');
const button = $('#signin-button');

// Already signed in? Go straight to the dashboard.
if (getUser()) {
  window.location.replace('dashboard.html');
}

showFlash();
clearErrorsOnInput(form);

form.addEventListener('submit', (event) => {
  event.preventDefault();
  if (isBusy(button)) {
    return;
  }

  const username = usernameInput.value.trim().toLowerCase();
  const password = passwordInput.value;
  const errors = {};

  if (!username) {
    errors.username = 'Enter your username.';
  }
  if (!password) {
    errors.password = 'Enter your password.';
  }
  if (Object.keys(errors).length) {
    clearMessages();
    showErrors(form, errors);
    return;
  }

  clearErrors(form);
  setBusy(button, true, 'Signing in…');
  setStatus('Signing in…', 'info');

  window.setTimeout(() => {
    const account = ACCOUNTS.find((item) => item.username === username && item.password === password);
    setBusy(button, false);

    if (!account) {
      clearMessages();
      // Do not say which of the two was wrong, as real systems do not.
      showErrors(form, {
        username: 'The username or password is not correct. Check both and try again, or use a demo account listed below.'
      });
      return;
    }

    setUser({ username: account.username, name: account.name, role: account.role, roleLabel: account.roleLabel });
    window.location.assign('dashboard.html');
  }, SIGN_IN_DELAY_MS);
});
