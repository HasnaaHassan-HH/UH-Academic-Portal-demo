/**
 * list.js - shared behaviour for the two record tables (students and marks):
 * searching, filtering, sorting, paging, loading and empty states.
 *
 * Both pages use the same element ids, so the tables look and behave the
 * same way everywhere (consistency).
 *
 * The current view is also kept in the page address (?q=...&page=2), so a
 * refresh or the Back button returns the user to exactly the same list.
 */

import { api } from './api.js';
import { $, showError } from './common.js';

const SEARCH_DELAY_MS = 300;
const DEFAULT_PAGE_SIZE = 10;

/**
 * @param {object} config
 * @param {string} config.endpoint  API address, e.g. "/students".
 * @param {{one: string, many: string}} config.noun  Used in status messages.
 * @param {{sort: string, order: 'asc'|'desc'}} config.defaults  Starting sort.
 * @param {(row: object) => HTMLTableRowElement} config.renderRow
 * @returns {{reload: () => Promise<void>}}
 */
export function initList({ endpoint, noun, defaults, renderRow }) {
  const form = $('#filters');
  const filterInputs = [...form.querySelectorAll('[data-filter]')];
  const sortSelect = $('#sort-by');
  const table = $('#records-table');
  const tableWrap = $('#table-wrap');
  const body = table.tBodies[0];
  const resultStatus = $('#result-status');
  const emptyState = $('#empty-state');
  const pagination = $('#pagination');
  const previousButton = $('#prev-page');
  const nextButton = $('#next-page');
  const pageInfo = $('#page-info');
  const pageSizeSelect = $('#page-size');

  const state = { ...defaults, page: 1, pageSize: DEFAULT_PAGE_SIZE };
  let lastPage = 1;
  let requestNumber = 0;
  let searchTimer;

  /* ----- Address bar <-> state ----- */

  function readAddress() {
    const params = new URLSearchParams(window.location.search);
    for (const input of filterInputs) {
      input.value = params.get(input.name) || '';
    }
    state.sort = params.get('sort') || defaults.sort;
    state.order = params.get('order') === 'desc' || (!params.has('order') && defaults.order === 'desc')
      ? 'desc' : 'asc';
    state.page = Math.max(1, Number.parseInt(params.get('page'), 10) || 1);
    state.pageSize = Number(params.get('pageSize')) || DEFAULT_PAGE_SIZE;
    pageSizeSelect.value = String(state.pageSize);
    if (!pageSizeSelect.value) {
      state.pageSize = DEFAULT_PAGE_SIZE;
      pageSizeSelect.value = String(DEFAULT_PAGE_SIZE);
    }
  }

  function buildQuery() {
    const params = new URLSearchParams();
    for (const input of filterInputs) {
      if (input.value.trim()) {
        params.set(input.name, input.value.trim());
      }
    }
    params.set('sort', state.sort);
    params.set('order', state.order);
    params.set('page', state.page);
    params.set('pageSize', state.pageSize);
    return params;
  }

  const filtersActive = () => filterInputs.some((input) => input.value.trim() !== '');

  /* ----- Rendering ----- */

  /** Update aria-sort and the arrow icon on each sortable column header. */
  function renderSortState() {
    for (const header of table.querySelectorAll('th[data-sort]')) {
      const active = header.dataset.sort === state.sort;
      const icon = $('.sort-icon', header);
      if (active) {
        header.setAttribute('aria-sort', state.order === 'asc' ? 'ascending' : 'descending');
        icon.textContent = state.order === 'asc' ? '▲' : '▼';
      } else {
        header.removeAttribute('aria-sort');
        icon.textContent = '↕';
      }
    }
    sortSelect.value = `${state.sort}:${state.order}`;
  }

  /**
   * aria-disabled (rather than disabled) keeps the button focusable, so a
   * keyboard user who reaches the last page does not lose their place.
   */
  function setButtonEnabled(button, enabled) {
    if (enabled) {
      button.removeAttribute('aria-disabled');
    } else {
      button.setAttribute('aria-disabled', 'true');
    }
  }

  function render({ rows, total, page, pageSize }) {
    state.page = page;
    lastPage = Math.max(1, Math.ceil(total / pageSize));

    body.replaceChildren(...rows.map(renderRow));
    renderSortState();

    const isEmpty = total === 0;
    tableWrap.hidden = isEmpty;
    pagination.hidden = isEmpty;
    emptyState.hidden = !isEmpty;

    pageInfo.textContent = `Page ${page} of ${lastPage}`;
    setButtonEnabled(previousButton, page > 1);
    setButtonEnabled(nextButton, page < lastPage);

    // Visible status that is also announced (role="status" in the HTML).
    if (isEmpty) {
      resultStatus.textContent = `No ${noun.many} found.`;
    } else {
      const from = (page - 1) * pageSize + 1;
      const to = from + rows.length - 1;
      const label = total === 1 ? noun.one : noun.many;
      const suffix = filtersActive() ? ' matching your filters' : '';
      resultStatus.textContent = `Showing ${from} to ${to} of ${total} ${label}${suffix}.`;
    }
  }

  /* ----- Loading ----- */

  async function load() {
    // Only the newest request may update the page (the user may type fast).
    requestNumber += 1;
    const thisRequest = requestNumber;
    const query = buildQuery();

    window.history.replaceState(null, '', `?${query}`);
    tableWrap.setAttribute('aria-busy', 'true');
    resultStatus.textContent = `Loading ${noun.many}…`;

    try {
      const data = await api(`${endpoint}?${query}`);
      if (thisRequest === requestNumber) {
        render(data);
      }
    } catch (error) {
      if (thisRequest === requestNumber) {
        resultStatus.textContent = `The ${noun.many} could not be loaded.`;
        showError(error.message);
      }
    } finally {
      if (thisRequest === requestNumber) {
        tableWrap.removeAttribute('aria-busy');
      }
    }
  }

  function changeSort(sort, order) {
    state.sort = sort;
    state.order = order;
    state.page = 1;
    load();
  }

  function goToPage(page) {
    if (page >= 1 && page <= lastPage && page !== state.page) {
      state.page = page;
      load();
    }
  }

  /* ----- Events ----- */

  // The Search button (or Enter in the search box) searches straight away,
  // without reloading the page.
  form.addEventListener('submit', (event) => {
    event.preventDefault();
    window.clearTimeout(searchTimer);
    state.page = 1;
    load();
  });

  form.addEventListener('input', (event) => {
    if (!event.target.matches('[data-filter]')) {
      return;
    }
    state.page = 1;
    // Wait for a pause in typing before searching.
    window.clearTimeout(searchTimer);
    searchTimer = window.setTimeout(load, event.target.type === 'search' ? SEARCH_DELAY_MS : 0);
  });

  for (const button of document.querySelectorAll('.js-clear-filters')) {
    button.addEventListener('click', () => {
      for (const input of filterInputs) {
        input.value = '';
      }
      state.page = 1;
      load();
      filterInputs[0].focus();
    });
  }

  // Sort by activating a column header...
  table.tHead.addEventListener('click', (event) => {
    const button = event.target.closest('button');
    if (!button) {
      return;
    }
    const { sort } = button.closest('th').dataset;
    const order = state.sort === sort && state.order === 'asc' ? 'desc' : 'asc';
    changeSort(sort, order);
  });

  // ...or with the "Sort by" list shown on small screens.
  sortSelect.addEventListener('change', () => {
    const [sort, order] = sortSelect.value.split(':');
    changeSort(sort, order);
  });

  previousButton.addEventListener('click', () => goToPage(state.page - 1));
  nextButton.addEventListener('click', () => goToPage(state.page + 1));

  pageSizeSelect.addEventListener('change', () => {
    state.pageSize = Number(pageSizeSelect.value);
    state.page = 1;
    load();
  });

  readAddress();
  load();

  return { reload: load };
}
