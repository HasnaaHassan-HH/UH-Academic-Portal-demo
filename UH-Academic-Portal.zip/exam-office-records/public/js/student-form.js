/**
 * student-form.js - add or edit a student record.
 * The same page does both: student-form.html adds, student-form.html?id=7 edits.
 */

import { api } from './api.js';
import { $, el, initPage, setStatus, setFlash, showError, clearMessages } from './common.js';
import { showErrors, clearErrors, clearErrorsOnInput, setBusy, isBusy, fieldId } from './forms.js';

const STUDENT_NO_PATTERN = /^S\d{6}$/;
const EMAIL_PATTERN = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

const user = initPage();
const form = $('#student-form');
const saveButton = $('#save-button');
const hasAccess = $('#has-access');
const accessSection = $('#access-section');
const editId = new URLSearchParams(window.location.search).get('id');

/** Show the arrangements fields only when the checkbox is ticked. */
function toggleAccessSection() {
  accessSection.hidden = !hasAccess.checked;
}

/** Read the form into the object the API expects. */
function readForm() {
  const data = new FormData(form);
  return {
    student_no: data.get('student_no').trim().toUpperCase(),
    first_name: data.get('first_name').trim(),
    last_name: data.get('last_name').trim(),
    email: data.get('email').trim(),
    programme: data.get('programme'),
    year: data.get('year'),
    mode: data.get('mode'),
    status: data.get('status'),
    has_access: hasAccess.checked,
    access_arrangements: data.getAll('access_arrangements'),
    access_notes: data.get('access_notes').trim()
  };
}

function fillForm(student) {
  $('#student-no').value = student.student_no;
  $('#first-name').value = student.first_name;
  $('#last-name').value = student.last_name;
  $('#email').value = student.email;
  $('#programme').value = student.programme;
  $('#year').value = String(student.year);
  form.elements.mode.value = student.mode;
  $('#status').value = student.status;
  hasAccess.checked = student.access_arrangements.length > 0;
  for (const box of form.querySelectorAll('[name="access_arrangements"]')) {
    box.checked = student.access_arrangements.includes(box.value);
  }
  $('#access-notes').value = student.access_notes;
  toggleAccessSection();
}

/**
 * Check the form before sending it, so mistakes are caught straight away.
 * The server repeats these checks. Messages say what to do, not just "invalid".
 * @returns {Object<string, string>} Map of field id -> message.
 */
function validate(values) {
  const errors = {};
  if (!STUDENT_NO_PATTERN.test(values.student_no)) {
    errors['student-no'] = 'Enter a student number as the letter S followed by 6 digits, for example S240123.';
  }
  if (!values.first_name) {
    errors['first-name'] = 'Enter a first name.';
  }
  if (!values.last_name) {
    errors['last-name'] = 'Enter a last name.';
  }
  if (!EMAIL_PATTERN.test(values.email)) {
    errors.email = 'Enter an email address in the format name@example.ac.uk.';
  }
  if (!values.programme) {
    errors.programme = 'Select a programme.';
  }
  if (!values.year) {
    errors.year = 'Select a year of study.';
  }
  if (values.has_access && values.access_arrangements.length === 0) {
    errors['access-arrangements'] = 'Select at least one arrangement, or untick "Has approved exam access arrangements".';
  }
  return errors;
}

async function save(event) {
  event.preventDefault();
  if (isBusy(saveButton)) {
    return;
  }

  const values = readForm();
  const errors = validate(values);
  if (Object.keys(errors).length) {
    clearMessages();
    showErrors(form, errors);
    return;
  }

  clearErrors(form);
  setBusy(saveButton, true, 'Saving…');
  setStatus('Saving student…', 'info');

  try {
    await api(editId ? `/students/${editId}` : '/students', {
      method: editId ? 'PUT' : 'POST',
      body: values
    });
    setFlash(`${editId ? 'Saved changes to' : 'Added'} ${values.first_name} ${values.last_name} (${values.student_no}).`);
    window.location.assign('students.html');
  } catch (error) {
    setBusy(saveButton, false);
    clearMessages();
    const serverErrors = Object.entries(error.fields);
    if (serverErrors.length) {
      // The server found a problem the browser could not, e.g. a duplicate number.
      showErrors(form, Object.fromEntries(serverErrors.map(([name, message]) => [fieldId(name), message])));
    } else {
      showError(error.message);
    }
  }
}

async function start() {
  // Only exams officers may change student records.
  if (user.role !== 'officer') {
    setFlash('Only exams officers can add or change student records.');
    window.location.replace('students.html');
    return;
  }

  try {
    const reference = await api('/reference');
    $('#programme').append(
      ...reference.programmes.map((programme) => el('option', { value: programme }, programme))
    );

    if (editId) {
      setStatus('Loading student…', 'info');
      const student = await api(`/students/${editId}`);
      fillForm(student);
      const title = `Edit ${student.first_name} ${student.last_name}`;
      $('#form-title').textContent = title;
      document.title = `${title} - Exam Office Records`;
      saveButton.textContent = 'Save changes';
      clearMessages();
    }
  } catch (error) {
    showError(error.message);
  }

  hasAccess.addEventListener('change', toggleAccessSection);
  clearErrorsOnInput(form);
  form.addEventListener('submit', save);
}

if (user) {
  start();
}
