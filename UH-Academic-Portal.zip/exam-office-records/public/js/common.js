/**
 * common.js - helpers shared by every signed-in page:
 * the simulated session, status/alert messages, the confirm dialog
 * and small formatting functions.
 */

const USER_KEY = 'examOffice.user';
const FLASH_KEY = 'examOffice.flash';

/** Shortcut for document.querySelector. */
export const $ = (selector, root = document) => root.querySelector(selector);

/**
 * Create an element safely. Text is always added with textContent/append,
 * never innerHTML, so data from the database cannot inject markup.
 * @param {string} tag
 * @param {Object<string, string|boolean|null>} [attributes] `false`/`null` values are skipped.
 * @param {...(Node|string)} children
 * @returns {HTMLElement}
 */
export function el(tag, attributes = {}, ...children) {
  const node = document.createElement(tag);
  for (const [name, value] of Object.entries(attributes)) {
    if (value === false || value === null || value === undefined) {
      continue;
    }
    if (name === 'class') {
      node.className = value;
    } else {
      node.setAttribute(name, value === true ? '' : value);
    }
  }
  node.append(...children);
  return node;
}

/** Text that only screen readers hear, used to make repeated links unique. */
export const srOnly = (text) => el('span', { class: 'visually-hidden' }, text);

/* ---------- Simulated session ---------- */

/** @returns {{username: string, name: string, role: string, roleLabel: string}|null} */
export function getUser() {
  try {
    return JSON.parse(sessionStorage.getItem(USER_KEY));
  } catch {
    return null;
  }
}

export function setUser(user) {
  sessionStorage.setItem(USER_KEY, JSON.stringify(user));
}

/**
 * Keep a message to show on the next page, e.g. "Student saved" after the
 * form sends the user back to the list.
 */
export function setFlash(message) {
  sessionStorage.setItem(FLASH_KEY, message);
}

function takeFlash() {
  const message = sessionStorage.getItem(FLASH_KEY);
  sessionStorage.removeItem(FLASH_KEY);
  return message;
}

/**
 * Run at the top of every signed-in page. Sends visitors who are not signed
 * in back to the sign-in screen, fills in the "Signed in as" text and wires
 * up the Sign out button.
 * @returns {object|null} The current user, or null while redirecting.
 */
export function initPage() {
  const user = getUser();
  if (!user) {
    setFlash('Please sign in to continue.');
    window.location.replace('index.html');
    return null;
  }

  $('#signed-in-as').textContent = `${user.name} (${user.roleLabel})`;
  $('#sign-out').addEventListener('click', () => {
    sessionStorage.removeItem(USER_KEY);
    setFlash('You have signed out.');
    window.location.assign('index.html');
  });

  showFlash();
  return user;
}

/** Show a message left by the previous page, if there is one. */
export function showFlash() {
  const message = takeFlash();
  if (message) {
    // Wait a moment: screen readers only announce changes made to a live
    // region after the page has finished loading.
    window.setTimeout(() => setStatus(message), 300);
  }
}

/* ---------- Status and alert messages ---------- */

function notice(type, icon, message) {
  return el('p', { class: `notice notice--${type}` },
    el('span', { class: 'notice__icon', 'aria-hidden': 'true' }, icon),
    el('span', {}, message));
}

/**
 * Show a message in the page's polite live region (role="status"),
 * so it is seen on screen and announced without interrupting.
 * @param {string} message
 * @param {'success'|'info'} [type] "info" is used for progress, e.g. "Saving".
 */
export function setStatus(message, type = 'success') {
  clearMessages();
  const icon = type === 'success' ? '\u2713' : '\u2026';
  $('#app-status').append(notice(type, icon, message));
}

/**
 * Show a problem in the page's assertive live region (role="alert"),
 * so screen readers announce it straight away.
 */
export function showError(message) {
  clearMessages();
  $('#app-alert').append(notice('error', '!', `Error: ${message}`));
}

export function clearMessages() {
  $('#app-status').replaceChildren();
  $('#app-alert').replaceChildren();
}

/* ---------- Confirm dialog ---------- */

/**
 * Ask the user to confirm a destructive action using the native <dialog>.
 * showModal() gives us the focus trap, Escape to cancel and the return of
 * focus for free, so no extra ARIA is needed.
 * @returns {Promise<boolean>} true when the user confirmed.
 */
export function confirmDialog({ title, message, confirmLabel }) {
  const dialog = $('#confirm-dialog');
  $('#confirm-title').textContent = title;
  $('#confirm-message').textContent = message;
  $('#confirm-ok').textContent = confirmLabel;

  return new Promise((resolve) => {
    dialog.returnValue = '';
    dialog.addEventListener('close', () => resolve(dialog.returnValue === 'confirm'), { once: true });
    dialog.showModal();
  });
}

/**
 * Move keyboard focus to the page heading, e.g. after the row that had
 * focus has been deleted, so focus is never left on a removed element.
 */
export function focusHeading() {
  const heading = $('h1');
  heading.tabIndex = -1;
  heading.focus();
}

/* ---------- Formatting ---------- */

const PASS_MARK = 40;

/** Degree classification for a final mark. */
export function classify(mark) {
  if (mark >= 70) { return 'First'; }
  if (mark >= 60) { return 'Upper second'; }
  if (mark >= 50) { return 'Lower second'; }
  if (mark >= PASS_MARK) { return 'Third'; }
  return 'Fail';
}

export const isPass = (mark) => mark >= PASS_MARK;

/** "active" -> "Active" */
export const capitalise = (text) => text.charAt(0).toUpperCase() + text.slice(1);

/** A <time> element showing e.g. "13 Nov 2026". */
export function dateElement(isoString) {
  const date = new Date(isoString);
  const label = date.toLocaleDateString('en-GB', { day: 'numeric', month: 'short', year: 'numeric' });
  return el('time', { datetime: isoString }, label);
}

/**
 * A text badge. The words carry the meaning; the icon and colour only
 * reinforce it, so nothing depends on colour alone (WCAG 1.4.1).
 * @param {'good'|'warn'|'bad'|'neutral'} tone
 */
export function badge(tone, text) {
  const icons = { good: '✓', warn: '▲', bad: '✕', neutral: '–' };
  return el('span', { class: `badge badge--${tone}` },
    el('span', { 'aria-hidden': 'true' }, icons[tone]), ` ${text}`);
}
