/**
 * forms.js - shared form validation feedback.
 *
 * Pattern used on every form (consistent, and friendly to screen readers):
 *  1. An error summary at the top lists every problem as a link to its field.
 *     It has role="alert" and receives focus, so it is announced at once.
 *  2. Each field also shows its own message underneath. The message element
 *     is referenced by the field's aria-describedby, so it is read out when
 *     the user reaches the field, and aria-invalid marks the field itself.
 *
 * Markup convention: a field with id="email" has <p id="email-error">.
 */

import { $, el } from './common.js';

/**
 * Convert a server field name to the matching input id
 * ("first_name" -> "first-name").
 */
export const fieldId = (name) => name.replace(/_/g, '-');

/** Remove every error message from a form and hide its summary. */
export function clearErrors(form) {
  const summary = $('.error-summary', form);
  summary.hidden = true;
  $('ul', summary).replaceChildren();

  for (const message of form.querySelectorAll('.field-error')) {
    message.replaceChildren();
  }
  for (const field of form.querySelectorAll('[aria-invalid]')) {
    field.removeAttribute('aria-invalid');
  }
}

/** Remove the error from one field (called when the user edits it). */
export function clearFieldError(field) {
  const message = document.getElementById(`${field.id}-error`);
  if (message) {
    message.replaceChildren();
  }
  field.removeAttribute('aria-invalid');
}

/**
 * Show one message under its field and mark the field as invalid.
 * @param {string} id      The field's id.
 * @param {string} message What is wrong and how to fix it.
 */
export function setFieldError(id, message) {
  const field = document.getElementById(id);
  const slot = document.getElementById(`${id}-error`);
  if (!field || !slot) {
    return;
  }
  slot.replaceChildren(
    el('span', { 'aria-hidden': 'true' }, '! '),
    el('span', { class: 'visually-hidden' }, 'Error: '),
    message
  );
  // Groups of checkboxes are wrapped in a <fieldset>, which cannot be
  // "invalid" itself; its message is still linked with aria-describedby.
  if (field.tagName !== 'FIELDSET') {
    field.setAttribute('aria-invalid', 'true');
  }
}

/**
 * Show validation errors next to their fields and in the summary,
 * then move focus to the summary.
 * @param {HTMLFormElement} form
 * @param {Object<string, string>} errors Map of field id -> message.
 */
export function showErrors(form, errors) {
  clearErrors(form);
  const summary = $('.error-summary', form);
  const list = $('ul', summary);

  for (const [id, message] of Object.entries(errors)) {
    setFieldError(id, message);
    list.append(el('li', {}, el('a', { href: `#${id}` }, message)));
  }

  summary.hidden = false;
  summary.focus();
}

/**
 * Clear a field's error as soon as the user starts correcting it, so stale
 * messages do not linger.
 */
export function clearErrorsOnInput(form) {
  const handler = (event) => {
    if (event.target.id) {
      clearFieldError(event.target);
    }
  };
  form.addEventListener('input', handler);
  form.addEventListener('change', handler);
}

/**
 * Put a submit button into (or out of) its "working" state. The button
 * keeps its place in the tab order (aria-disabled, not disabled) so
 * keyboard focus is not lost while saving.
 */
export function setBusy(button, busy, busyLabel) {
  if (busy) {
    button.dataset.label = button.textContent;
    button.textContent = busyLabel;
    button.setAttribute('aria-disabled', 'true');
  } else {
    button.textContent = button.dataset.label || button.textContent;
    button.removeAttribute('aria-disabled');
  }
}

/** True while a button is in its "working" state (ignore extra clicks). */
export const isBusy = (button) => button.getAttribute('aria-disabled') === 'true';
