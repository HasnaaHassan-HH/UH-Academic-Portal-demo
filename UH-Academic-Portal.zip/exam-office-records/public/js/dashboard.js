/**
 * dashboard.js - fills the dashboard with live figures from the server.
 */

import { api } from './api.js';
import { $, el, initPage, showError, dateElement, isPass, capitalise } from './common.js';

const user = initPage();

/** One-line description of a mark's result, e.g. "62 (pass)". */
function describeResult(mark) {
  if (mark.outcome !== 'submitted') {
    return capitalise(mark.outcome);
  }
  return `${mark.final_mark} (${isPass(mark.final_mark) ? 'pass' : 'fail'})`;
}

function renderModules(modules) {
  $('#module-rows').replaceChildren(...modules.map((module) => el('tr', {},
    el('th', { scope: 'row' }, `${module.code} ${module.title}`),
    el('td', { class: 'numeric' }, String(module.recorded)),
    el('td', { class: 'numeric' }, module.average === null ? 'No marks' : String(module.average))
  )));
}

function renderRecent(recent) {
  $('#recent-empty').hidden = recent.length > 0;
  $('#recent-list').replaceChildren(...recent.map((mark) => el('li', {},
    el('a', { href: `mark-form.html?id=${mark.id}` }, `${mark.first_name} ${mark.last_name}`),
    ` – ${mark.module_code} ${mark.assessment_title}: ${describeResult(mark)}, `,
    dateElement(mark.updated_at)
  )));
}

async function loadSummary() {
  const status = $('#summary-status');
  try {
    const summary = await api('/summary');

    $('#stat-active').textContent = `${summary.students.active} of ${summary.students.total}`;
    $('#stat-marks').textContent = summary.marks.total;
    $('#stat-average').textContent = summary.marks.average === null ? 'No marks' : summary.marks.average;
    $('#stat-fails').textContent = summary.marks.fails;
    $('#stat-absent').textContent = summary.marks.absent;
    renderModules(summary.modules);
    renderRecent(summary.recent);

    const time = new Date().toLocaleTimeString('en-GB', { hour: '2-digit', minute: '2-digit' });
    status.textContent = `Figures up to date at ${time}.`;
  } catch (error) {
    status.textContent = 'The summary could not be loaded.';
    showError(error.message);
  }
}

if (user) {
  $('#welcome').textContent = `Welcome back, ${user.name}. You are signed in as ${user.roleLabel.toLowerCase()}.`;
  // Only exams officers may add student records.
  $('#add-student-action').hidden = user.role !== 'officer';
  loadSummary();
}
