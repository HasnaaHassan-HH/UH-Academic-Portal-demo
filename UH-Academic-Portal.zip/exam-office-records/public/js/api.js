/**
 * api.js - one small wrapper around fetch() for talking to the server.
 * Every page uses it, so errors are reported in the same way everywhere.
 */

/** Error with the HTTP status and any per-field messages from the server. */
export class ApiError extends Error {
  /**
   * @param {string} message Human-readable message, safe to show to staff.
   * @param {number} status  HTTP status code (0 when the server was unreachable).
   * @param {object} [data]  Full JSON body of the error response.
   */
  constructor(message, status, data = {}) {
    super(message);
    this.name = 'ApiError';
    this.status = status;
    this.fields = data.fields || {};
    this.data = data;
  }
}

/**
 * Call the JSON API.
 * @param {string} path Address after /api, for example "/students?page=2".
 * @param {{method?: string, body?: object}} [options]
 * @returns {Promise<object|null>} Parsed JSON (null for "204 No Content").
 */
export async function api(path, { method = 'GET', body } = {}) {
  let response;
  try {
    response = await fetch(`/api${path}`, {
      method,
      headers: body ? { 'Content-Type': 'application/json' } : undefined,
      body: body ? JSON.stringify(body) : undefined
    });
  } catch {
    throw new ApiError('Could not reach the server. Check your connection and try again.', 0);
  }

  let data = null;
  if (response.status !== 204) {
    data = await response.json().catch(() => null);
  }

  // The server answers an expected problem (a form that fails validation,
  // a student number that does not exist) with { ok: false }.
  const rejected = data !== null && data.ok === false;
  if (!response.ok || rejected) {
    const message = (data && data.error) || 'Something went wrong. Please try again.';
    throw new ApiError(message, rejected ? 422 : response.status, data || {});
  }
  return data;
}
