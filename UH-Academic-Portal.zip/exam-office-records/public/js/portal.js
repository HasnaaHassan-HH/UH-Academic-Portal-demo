import { $, getUser, initPage, el, showError } from './common.js';

const user = initPage();
if (user) {
  const isStudent = user.role === 'student';
  const isTeacher = user.role === 'tutor';
  const viewRoot = $('#portal-view');
  const navRoot = $('#portal-nav');
  const pages = [
    ['dashboard','▦','Dashboard','all'], ['teachers','♙','Teachers','staff'], ['students','♧','Students','staff'],
    ['modules','▤','Modules','all'], ['notices','◉','Notices','all'], ['attendance','▣','Attendance','all'],
    ['exams','▦','Exams','all'], ['grades','✓','Exam grades','student'], ['marks','▥','Marks','staff'], ['messages','✉','Messages','all'], ['profile','○','My profile','all']
  ];
  $('#signed-in-as').textContent = `${user.name} · ${user.roleLabel}`;
  $('#user-name').textContent = user.name;
  $('#avatar-initials').textContent = user.name.split(/\s+/).map(x=>x[0]).slice(0,2).join('').toUpperCase();

  const allowed = pages.filter(p => p[3] === 'all' || (p[3] === 'staff' && !isStudent) || (p[3] === 'student' && isStudent));
  navRoot.replaceChildren(...allowed.map(([id,icon,label]) => {
    const a = el('a',{href:`#${id}`,class:'mars-nav-link','data-view':id},el('span',{class:'nav-icon','aria-hidden':'true'},icon),el('span',{},label));
    return a;
  }));
  const data = {
    notices:[['Library extended hours','The library will remain open until 10pm during the examination period.','Today','Academic Services'],['Semester timetable published','Your updated teaching timetable is now available.','Yesterday','Registry'],['Campus maintenance','Some study spaces will be unavailable this weekend.','12 Nov 2026','Estates']],
    teachers:[['Dr Sarah Mitchell','sarah.mitchell@herts.ac.uk','Computer Science','Senior Lecturer'],['Mr James Patel','j.patel@herts.ac.uk','Mathematics','Module Tutor'],['Dr Amina Yusuf','a.yusuf@herts.ac.uk','Business','Programme Lead'],['Ms Emily Carter','e.carter@herts.ac.uk','Design','Lecturer']],
    students:[['S240001','Amira Hassan','Computer Science','Year 2','Active'],['S240008','Daniel Okafor','Business Management','Year 1','Active'],['S240015','Priya Sharma','Cyber Security','Year 3','Active'],['S240022','Tomasz Kowalski','Computer Science','Year 2','Interrupted']],
    modules:[['4COM2001','Software Engineering','20 credits','Semester A'],['4COM2002','Database Systems','15 credits','Semester A'],['4COM2003','Web Application Development','15 credits','Semester B'],['4COM2004','Professional Practice','30 credits','Full year'],['4MAT1001','Mathematics for Computing','15 credits','Semester B']],
    exams:[['4COM2001','Software Engineering','18 Nov 2026','09:00–11:00','Room B.01'],['4COM2002','Database Systems','21 Nov 2026','13:00–15:00','Room L.204'],['4COM2003','Web Application Development','25 Nov 2026','09:00–11:00','Room C.12'],['4MAT1001','Mathematics for Computing','28 Nov 2026','11:00–13:00','Main Hall']],
    attendance:[['Software Engineering','92%','18 / 20','Good'],['Database Systems','86%','18 / 21','Good'],['Web Application Development','78%','14 / 18','Review'],['Mathematics for Computing','95%','19 / 20','Good']],
    grades:[['4COM2001','Software Engineering','Coursework','72','First'],['4COM2002','Database Systems','Mid-term test','64','Upper second'],['4COM2003','Web Application Development','Practical','—','Pending'],['4MAT1001','Mathematics for Computing','Coursework','58','Lower second']]
  };
  const mk = (tag,cls,txt)=>el(tag,{class:cls||''},txt||'');
  const stat = (label,value,detail,icon)=>el('article',{class:'metric-card'},el('span',{class:'metric-icon','aria-hidden':'true'},icon),el('div',{},mk('p','metric-label',label),mk('strong','metric-value',value),mk('small','metric-detail',detail)));
  const section = (title,content,extra='')=>el('section',{class:`panel ${extra}`},mk('h2','panel-title',title),content);
  function table(headers, rows) { const t=el('div',{class:'table-scroll'}); const table=el('table',{class:'mars-table'}); table.append(el('thead',{},el('tr',{},...headers.map(h=>el('th',{scope:'col'},h))))); table.append(el('tbody',{},...rows.map(row=>el('tr',{},...row.map(cell=>el('td',{},cell))))));t.append(table);return t; }
  function cardGrid(items){return el('div',{class:'metric-grid'},...items)}
  function dashboard(){
    const intro=isStudent?'Here is your academic overview for the current semester.':'Here is an overview of academic activity across the university portal.';
    $('#welcome').textContent=intro;
    const cards=isStudent?[stat('Enrolled modules','5','Current academic year','▤'),stat('Overall attendance','88%','Across your modules','▣'),stat('Average grade','64%','Current recorded marks','✓'),stat('Upcoming exams','4','Next exam in 4 days','▦')]:[stat('Students','2,450','Registered student records','♧'),stat('Teachers','320','Academic staff','♙'),stat('Modules','120','Available modules','▤'),stat('Upcoming exams','12','Scheduled this month','▦')];
    const left=section(isStudent?'My module attendance':'Attendance overview',el('div',{class:'attendance-summary'},el('div',{class:'donut'},el('strong',{},isStudent?'88%':'92%'),el('small',{},'Attendance')),el('div',{class:'attendance-bars'},...['Software Engineering','Database Systems','Web Development'].map((x,i)=>el('div',{class:'bar-row'},el('span',{},x),el('div',{class:'bar-track'},el('i',{style:`width:${[92,86,78][i]}%`})),el('b',{},`${[92,86,78][i]}%`))))));
    const right=section('Recent announcements',el('div',{class:'announcement-list'},...data.notices.slice(0,3).map(n=>el('article',{class:'announcement-item'},mk('small','muted',n[2]),mk('h3','',n[0]),mk('p','',n[1])))));
    const examRows=data.exams.slice(0,3).map(e=>e);
    viewRoot.replaceChildren(cardGrid(cards),el('div',{class:'dashboard-columns'},left,right),section('Upcoming exam schedule',table(['Module code','Module','Date','Time','Location'],examRows)));
  }
  function renderList(view){
    const configs={teachers:['Teachers','Academic staff directory',['Name','Email','School','Role'],data.teachers],students:['Students','Student records and enrolment overview',['Student ID','Student name','Programme','Year','Status'],data.students],modules:['Modules','Module catalogue and semester information',['Code','Module title','Credits','Semester'],data.modules],exams:['Exam schedule','Upcoming examinations and locations',['Module code','Module','Date','Time','Location'],data.exams],attendance:['Attendance','Attendance records by module',['Module','Attendance','Classes attended','Status'],data.attendance],grades:['Exam grades','Your recorded assessment results',['Module code','Module','Assessment','Mark','Classification'],data.grades],marks:['Marks','Assessment marks and moderation records',['Module code','Module','Assessment','Mark','Status'],data.grades.map(g=>[...g.slice(0,4),g[4]])]};
    const [title,desc,headers,rows]=configs[view]; $('#welcome').textContent=desc;
    const search=el('input',{type:'search',placeholder:`Search ${title.toLowerCase()}…`,'aria-label':`Search ${title}`});
    const body=el('div',{class:'panel'},el('div',{class:'list-toolbar'},mk('p','muted',`${rows.length} records shown`),search),table(headers,rows));
    search.addEventListener('input',()=>{const q=search.value.toLowerCase();for(const tr of body.querySelectorAll('tbody tr'))tr.hidden=!tr.textContent.toLowerCase().includes(q)});
    viewRoot.replaceChildren(body);
  }
  function notices(){ $('#welcome').textContent='University updates, academic announcements and important reminders.';viewRoot.replaceChildren(...data.notices.map(n=>el('article',{class:'panel notice-card'},el('div',{class:'notice-meta'},mk('span','tag','Announcement'),mk('small','muted',n[2])),mk('h2','',n[0]),mk('p','',n[1]),mk('small','muted',`Published by ${n[3]}`)))); }
  function profile(){ $('#welcome').textContent='View your account details and university information.';const fields=[['Full name',user.name],['Username',user.username],['Role',user.roleLabel],['University','University of Hertfordshire'],['Portal','MARS']];viewRoot.replaceChildren(section('Account information',el('dl',{class:'profile-grid'},...fields.flatMap(([k,v])=>[mk('dt','',k),mk('dd','',v)])))); }
  function messages(){ $('#welcome').textContent='Your university messages and support contacts.';viewRoot.replaceChildren(section('Inbox',el('div',{class:'empty-state'},mk('strong','', 'You’re all caught up'),mk('p','muted','There are no new messages in this demo account.')))); }
  function show(view){ if(!allowed.some(p=>p[0]===view))view='dashboard';const page=pages.find(p=>p[0]===view);$('#page-title').textContent=page[2];$('#page-kicker').textContent=view==='dashboard'?'OVERVIEW':'UH Academic Portal · '+page[2].toUpperCase();document.querySelectorAll('[data-view]').forEach(a=>a.classList.toggle('active',a.dataset.view===view));const actions=$('#page-actions');actions.replaceChildren();if(!isStudent&&view==='students')actions.append(el('a',{class:'mars-action-link',href:'students.html'},'Open student records manager →'));if(!isStudent&&view==='marks')actions.append(el('a',{class:'mars-action-link',href:'marks.html'},'Open marks manager →'));if(view==='dashboard')dashboard();else if(view==='notices')notices();else if(view==='profile')profile();else if(view==='messages')messages();else renderList(view);}
  function route(){show(location.hash.slice(1)||'dashboard')};window.addEventListener('hashchange',route);route();
  $('#global-search').addEventListener('keydown',e=>{if(e.key==='Enter'){const q=e.currentTarget.value.trim();if(q){location.hash='students';setTimeout(()=>{const input=viewRoot.querySelector('input[type=search]');if(input){input.value=q;input.dispatchEvent(new Event('input'));}},0)}}});
  $('#notification-button').addEventListener('click',()=>{location.hash='notices'});
}
