/**
 * students.js - the student records table.
 */

import { api } from './api.js';
import {
  $, el, srOnly, initPage, setStatus, showError, confirmDialog, focusHeading, badge, capitalise
} from './common.js';
import { initList } from './list.js';

const STATUS_TONES = { active: 'good', interrupted: 'warn', withdrawn: 'bad' };

const user = initPage();
const canEdit = user && user.role === 'officer';
let list;

/**
 * A table cell. The label is hidden on wide screens (the column header does
 * that job) and shown on small screens, where each row becomes a card.
 */
function cell(label, ...content) {
  return el('td', {}, el('span', { class: 'cell-label' }, `${label}: `), ...content);
}

async function deleteStudent(student, name) {
  const confirmed = await confirmDialog({
    title: `Delete ${name}?`,
    message: `This deletes the record for ${name} (${student.student_no}) and any marks recorded for them. It cannot be undone.`,
    confirmLabel: 'Delete student'
  });
  if (!confirmed) {
    return;
  }
  try {
    await api(`/students/${student.id}`, { method: 'DELETE' });
    await list.reload();
    setStatus(`Deleted the record for ${name} (${student.student_no}).`);
    focusHeading();
  } catch (error) {
    showError(error.message);
  }
}

function renderRow(student) {
  const name = `${student.first_name} ${student.last_name}`;

  // Every link names the student for screen readers, so a list of links
  // does not read "Edit, Edit, Edit".
  const actions = [
    el('a', { href: `mark-form.html?student=${student.student_no}` }, 'Enter mark', srOnly(` for ${name}`))
  ];
  if (canEdit) {
    const deleteButton = el('button', { type: 'button', class: 'link-button link-button--danger' },
      'Delete', srOnly(` ${name}`));
    deleteButton.addEventListener('click', () => deleteStudent(student, name));
    actions.push(
      el('a', { href: `student-form.html?id=${student.id}` }, 'Edit', srOnly(` ${name}`)),
      deleteButton
    );
  }

  return el('tr', {},
    cell('Student no.', student.student_no),
    el('th', { scope: 'row' }, name),
    cell('Programme', student.programme),
    cell('Year', String(student.year)),
    cell('Status', badge(STATUS_TONES[student.status], capitalise(student.status))),
    el('td', { class: 'actions' }, ...actions));
}

async function start() {
  // Only exams officers may add, edit or delete student records.
  $('#add-student').hidden = !canEdit;

  // Fill the Programme filter before the list reads the page address.
  try {
    const reference = await api('/reference');
    $('#filter-programme').append(
      ...reference.programmes.map((programme) => el('option', { value: programme }, programme))
    );
  } catch (error) {
    showError(error.message);
  }

  list = initList({
    endpoint: '/students',
    noun: { one: 'student', many: 'students' },
    defaults: { sort: 'last_name', order: 'asc' },
    renderRow
  });
}

if (user) {
  start();
}
