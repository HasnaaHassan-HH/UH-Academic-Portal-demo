/**
 * marks.js - the recorded marks table.
 */

import { api } from './api.js';
import {
  $, el, srOnly, initPage, setStatus, showError, confirmDialog, focusHeading,
  badge, classify, isPass, dateElement
} from './common.js';
import { initList } from './list.js';

const user = initPage();
let list;

/** See students.js: label is shown only in the small-screen card layout. */
function cell(label, ...content) {
  return el('td', {}, el('span', { class: 'cell-label' }, `${label}: `), ...content);
}

/** The Result cell: mark, pass/fail badge and any late-submission note. */
function resultContent(mark) {
  if (mark.outcome === 'absent') {
    return [badge('warn', 'Absent')];
  }
  if (mark.outcome === 'deferred') {
    return [badge('neutral', 'Deferred')];
  }
  const content = [
    el('strong', {}, String(mark.final_mark)),
    ' ',
    isPass(mark.final_mark)
      ? badge('good', `Pass (${classify(mark.final_mark)})`)
      : badge('bad', 'Fail')
  ];
  if (mark.late_days > 0 && mark.mark > mark.final_mark) {
    content.push(el('span', { class: 'note' }, ` Late: capped from ${mark.mark}`));
  }
  return content;
}

async function deleteMark(mark, description) {
  const confirmed = await confirmDialog({
    title: 'Delete this mark?',
    message: `This deletes the mark for ${description}. It cannot be undone.`,
    confirmLabel: 'Delete mark'
  });
  if (!confirmed) {
    return;
  }
  try {
    await api(`/marks/${mark.id}`, { method: 'DELETE' });
    await list.reload();
    setStatus(`Deleted the mark for ${description}.`);
    focusHeading();
  } catch (error) {
    showError(error.message);
  }
}

function renderRow(mark) {
  const name = `${mark.first_name} ${mark.last_name}`;
  const assessment = mark.attempt === 'resit' ? `${mark.assessment_title} (resit)` : mark.assessment_title;
  const description = `${name}, ${mark.module_code} ${assessment}`;

  const deleteButton = el('button', { type: 'button', class: 'link-button link-button--danger' },
    'Delete', srOnly(` mark for ${description}`));
  deleteButton.addEventListener('click', () => deleteMark(mark, description));

  return el('tr', {},
    el('th', { scope: 'row' },
      name, el('span', { class: 'sub' }, mark.student_no)),
    cell('Module', mark.module_code),
    cell('Assessment', assessment),
    cell('Result', ...resultContent(mark)),
    cell('Last updated', dateElement(mark.updated_at)),
    el('td', { class: 'actions' },
      el('a', { href: `mark-form.html?id=${mark.id}` }, 'Edit', srOnly(` mark for ${description}`)),
      deleteButton));
}

async function start() {
  // Fill the Module filter before the list reads the page address.
  try {
    const reference = await api('/reference');
    $('#filter-module').append(...reference.modules.map(
      (module) => el('option', { value: module.code }, `${module.code} ${module.title}`)
    ));
  } catch (error) {
    showError(error.message);
  }

  list = initList({
    endpoint: '/marks',
    noun: { one: 'mark', many: 'marks' },
    defaults: { sort: 'updated_at', order: 'desc' },
    renderRow
  });
}

if (user) {
  start();
}
