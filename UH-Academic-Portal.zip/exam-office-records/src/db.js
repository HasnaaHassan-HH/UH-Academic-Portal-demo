'use strict';

/**
 * Database layer: opens the SQLite file, creates the tables the first time
 * the server runs, and fills them with fictional demo data.
 */

const fs = require('fs');
const path = require('path');
// SQLite is built into Node.js (22.13 or newer), so nothing extra to install.
const { DatabaseSync } = require('node:sqlite');
const ref = require('./reference');

const SCHEMA = `
  CREATE TABLE IF NOT EXISTS students (
    id                  INTEGER PRIMARY KEY AUTOINCREMENT,
    student_no          TEXT    NOT NULL UNIQUE,
    first_name          TEXT    NOT NULL,
    last_name           TEXT    NOT NULL,
    email               TEXT    NOT NULL,
    programme           TEXT    NOT NULL,
    year                INTEGER NOT NULL,
    mode                TEXT    NOT NULL,
    status              TEXT    NOT NULL,
    access_arrangements TEXT    NOT NULL DEFAULT '[]',
    access_notes        TEXT    NOT NULL DEFAULT '',
    updated_at          TEXT    NOT NULL
  );

  CREATE TABLE IF NOT EXISTS modules (
    code  TEXT PRIMARY KEY,
    title TEXT NOT NULL
  );

  CREATE TABLE IF NOT EXISTS assessments (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    module_code TEXT NOT NULL REFERENCES modules(code),
    title       TEXT NOT NULL
  );

  CREATE TABLE IF NOT EXISTS marks (
    id             INTEGER PRIMARY KEY AUTOINCREMENT,
    student_id     INTEGER NOT NULL REFERENCES students(id) ON DELETE CASCADE,
    assessment_id  INTEGER NOT NULL REFERENCES assessments(id),
    attempt        TEXT    NOT NULL,
    outcome        TEXT    NOT NULL,
    mark           INTEGER,
    late_days      INTEGER NOT NULL DEFAULT 0,
    final_mark     INTEGER,
    absence_reason TEXT,
    moderated      INTEGER NOT NULL DEFAULT 0,
    comment        TEXT    NOT NULL DEFAULT '',
    entered_by     TEXT    NOT NULL DEFAULT '',
    updated_at     TEXT    NOT NULL,
    UNIQUE (student_id, assessment_id, attempt)
  );
`;

/* ---------- Demo data ---------- */

const FIRST_NAMES = [
  'Amira', 'Daniel', 'Priya', 'Tomasz', 'Chloe', 'Kwame', 'Sofia', 'Liam',
  'Mei', 'Omar', 'Hannah', 'Rafael', 'Aisha', 'Ethan', 'Yuki', 'Noah',
  'Fatima', 'Lucas', 'Zara', 'Mateo', 'Ingrid', 'Samuel', 'Leila', 'Oscar'
];

const LAST_NAMES = [
  'Hassan', 'Okafor', 'Sharma', 'Kowalski', 'Bennett', 'Mensah', 'Rossi',
  'Murphy', 'Chen', 'Farouk', 'Schmidt', 'Silva', 'Khan', 'Wright',
  'Tanaka', 'Evans', 'Aziz', 'Dubois', 'Patel', 'Garcia', 'Larsen', 'Adeyemi'
];

/**
 * Small repeatable pseudo-random generator, so every fresh install gets
 * exactly the same demo data (useful when comparing test results).
 */
function createRandom(seed) {
  let value = seed;
  return function random() {
    value = (value * 1664525 + 1013904223) % 4294967296;
    return value / 4294967296;
  };
}

/** The mark that counts: late work is capped at the pass mark. */
function calculateFinalMark(outcome, mark, lateDays) {
  if (outcome !== 'submitted') {
    return null;
  }
  return lateDays > 0 ? Math.min(mark, ref.PASS_MARK) : mark;
}

function seed(db) {
  const random = createRandom(2026);
  const pick = (list) => list[Math.floor(random() * list.length)];
  const now = Date.now();

  const insertModule = db.prepare('INSERT INTO modules (code, title) VALUES (?, ?)');
  const insertAssessment = db.prepare('INSERT INTO assessments (module_code, title) VALUES (?, ?)');
  const insertStudent = db.prepare(`
    INSERT INTO students (student_no, first_name, last_name, email, programme, year, mode,
                          status, access_arrangements, access_notes, updated_at)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`);
  const insertMark = db.prepare(`
    INSERT INTO marks (student_id, assessment_id, attempt, outcome, mark, late_days, final_mark,
                       absence_reason, moderated, comment, entered_by, updated_at)
    VALUES (?, ?, 'first', ?, ?, ?, ?, ?, ?, '', 'Seed data', ?)`);

  // One transaction: either all the demo data is saved or none of it.
  db.exec('BEGIN');
  try {
    const assessmentIds = [];
    for (const module of ref.MODULES) {
      insertModule.run(module.code, module.title);
      for (const title of module.assessments) {
        assessmentIds.push(insertAssessment.run(module.code, title).lastInsertRowid);
      }
    }

    for (let index = 0; index < 64; index += 1) {
      const firstName = pick(FIRST_NAMES);
      const lastName = pick(LAST_NAMES);
      const studentNo = `S${240001 + index * 7}`;
      const statusRoll = random();
      const status = statusRoll < 0.84 ? 'active' : statusRoll < 0.93 ? 'interrupted' : 'withdrawn';
      const arrangements = random() < 0.12 ? ['extra-time'] : [];
      const updatedAt = new Date(now - Math.floor(random() * 60) * 86400000).toISOString();

      const studentId = insertStudent.run(
        studentNo,
        firstName,
        lastName,
        `${studentNo.toLowerCase()}@student.example.ac.uk`,
        pick(ref.PROGRAMMES),
        1 + Math.floor(random() * 3),
        random() < 0.85 ? 'full-time' : 'part-time',
        status,
        JSON.stringify(arrangements),
        '',
        updatedAt
      ).lastInsertRowid;

      // Give most students marks for a handful of assessments.
      for (const assessmentId of assessmentIds) {
        if (random() > 0.3) {
          continue;
        }
        const absent = random() < 0.06;
        const mark = absent ? null : Math.min(100, Math.max(12, Math.round(38 + random() * 50)));
        const lateDays = !absent && random() < 0.08 ? 1 + Math.floor(random() * 3) : 0;
        const outcome = absent ? 'absent' : 'submitted';
        insertMark.run(
          studentId,
          assessmentId,
          outcome,
          mark,
          lateDays,
          calculateFinalMark(outcome, mark, lateDays),
          absent ? 'unauthorised' : null,
          random() < 0.25 ? 1 : 0,
          new Date(now - Math.floor(random() * 30) * 86400000).toISOString()
        );
      }
    }
    db.exec('COMMIT');
  } catch (error) {
    db.exec('ROLLBACK');
    throw error;
  }
}

/**
 * Open (or create) the database file and make sure it is ready to use.
 * @param {string} file Path to the SQLite file.
 */
function openDatabase(file) {
  fs.mkdirSync(path.dirname(file), { recursive: true });
  const db = new DatabaseSync(file);
  db.exec('PRAGMA journal_mode = WAL');
  db.exec('PRAGMA foreign_keys = ON');
  db.exec(SCHEMA);

  const { count } = db.prepare('SELECT COUNT(*) AS count FROM students').get();
  if (count === 0) {
    seed(db);
  }
  return db;
}

module.exports = { openDatabase, calculateFinalMark };
