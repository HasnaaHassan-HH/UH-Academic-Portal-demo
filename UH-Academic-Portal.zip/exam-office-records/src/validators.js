'use strict';

/**
 * Server-side validation. The browser checks the same rules first so staff
 * get instant feedback, but the server never trusts what it is sent.
 *
 * Each function returns { errors, value }:
 *   errors - object of fieldName -> message (empty when everything is valid)
 *   value  - cleaned data that is safe to store
 */

const ref = require('./reference');

const STUDENT_NO_PATTERN = /^S\d{6}$/;
const EMAIL_PATTERN = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
const MAX_NOTE_LENGTH = 300;

const text = (input) => (typeof input === 'string' ? input.trim() : '');

function validateStudent(body) {
  const errors = {};
  const value = {
    student_no: text(body.student_no).toUpperCase(),
    first_name: text(body.first_name),
    last_name: text(body.last_name),
    email: text(body.email).toLowerCase(),
    programme: text(body.programme),
    year: Number(body.year),
    mode: text(body.mode),
    status: text(body.status),
    access_arrangements: Array.isArray(body.access_arrangements) ? body.access_arrangements : [],
    access_notes: text(body.access_notes)
  };

  if (!STUDENT_NO_PATTERN.test(value.student_no)) {
    errors.student_no = 'Enter a student number as the letter S followed by 6 digits, for example S240123.';
  }
  if (!value.first_name || value.first_name.length > 60) {
    errors.first_name = 'Enter a first name of up to 60 characters.';
  }
  if (!value.last_name || value.last_name.length > 60) {
    errors.last_name = 'Enter a last name of up to 60 characters.';
  }
  if (!EMAIL_PATTERN.test(value.email)) {
    errors.email = 'Enter an email address in the format name@example.ac.uk.';
  }
  if (!ref.PROGRAMMES.includes(value.programme)) {
    errors.programme = 'Select a programme.';
  }
  if (![1, 2, 3, 4].includes(value.year)) {
    errors.year = 'Select a year of study.';
  }
  if (!ref.STUDY_MODES.includes(value.mode)) {
    errors.mode = 'Select a study mode.';
  }
  if (!ref.STUDENT_STATUSES.includes(value.status)) {
    errors.status = 'Select a status.';
  }

  const allowed = ref.ACCESS_ARRANGEMENTS.map((item) => item.value);
  value.access_arrangements = value.access_arrangements.filter((item) => allowed.includes(item));
  if (body.has_access && value.access_arrangements.length === 0) {
    errors.access_arrangements = 'Select at least one arrangement, or untick "Has approved exam access arrangements".';
  }
  if (!body.has_access) {
    value.access_arrangements = [];
    value.access_notes = '';
  }
  if (value.access_notes.length > MAX_NOTE_LENGTH) {
    errors.access_notes = `Notes must be ${MAX_NOTE_LENGTH} characters or fewer.`;
  }

  return { errors, value };
}

function validateMark(body) {
  const errors = {};
  const value = {
    student_no: text(body.student_no).toUpperCase(),
    assessment_id: Number(body.assessment_id),
    attempt: text(body.attempt),
    outcome: text(body.outcome),
    mark: null,
    late_days: 0,
    absence_reason: null,
    moderated: body.moderated ? 1 : 0,
    comment: text(body.comment),
    entered_by: text(body.entered_by).slice(0, 60)
  };

  if (!STUDENT_NO_PATTERN.test(value.student_no)) {
    errors.student_no = 'Enter a student number as the letter S followed by 6 digits, for example S240123.';
  }
  if (!Number.isInteger(value.assessment_id) || value.assessment_id < 1) {
    errors.assessment_id = 'Select an assessment.';
  }
  if (!ref.ATTEMPTS.includes(value.attempt)) {
    errors.attempt = 'Select an attempt.';
  }
  if (!ref.OUTCOMES.includes(value.outcome)) {
    errors.outcome = 'Select an outcome.';
  }

  if (value.outcome === 'submitted') {
    const mark = Number(body.mark);
    if (body.mark === '' || body.mark === null || body.mark === undefined
        || !Number.isInteger(mark) || mark < 0 || mark > 100) {
      errors.mark = 'Enter a mark as a whole number from 0 to 100.';
    } else {
      value.mark = mark;
    }
    if (body.late) {
      const lateDays = Number(body.late_days);
      if (!Number.isInteger(lateDays) || lateDays < 1 || lateDays > ref.MAX_LATE_DAYS) {
        errors.late_days = `Enter the number of days late as a whole number from 1 to ${ref.MAX_LATE_DAYS}.`;
      } else {
        value.late_days = lateDays;
      }
    }
  }

  if (value.outcome === 'absent') {
    const reasons = ref.ABSENCE_REASONS.map((item) => item.value);
    if (!reasons.includes(body.absence_reason)) {
      errors.absence_reason = 'Select a reason for the absence.';
    } else {
      value.absence_reason = body.absence_reason;
    }
  }

  if (value.comment.length > MAX_NOTE_LENGTH) {
    errors.comment = `Comment must be ${MAX_NOTE_LENGTH} characters or fewer.`;
  }

  return { errors, value };
}

/** Read paging and sorting options from a query string safely. */
function readListOptions(query, sortableColumns, defaultSort) {
  const pageSize = [10, 25, 50].includes(Number(query.pageSize)) ? Number(query.pageSize) : 10;
  const page = Math.max(1, Number.parseInt(query.page, 10) || 1);
  const sort = Object.hasOwn(sortableColumns, query.sort) ? query.sort : defaultSort;
  const order = query.order === 'desc' ? 'DESC' : 'ASC';
  return { page, pageSize, sort, order };
}

module.exports = { validateStudent, validateMark, readListOptions };
