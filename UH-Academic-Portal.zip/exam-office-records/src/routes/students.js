'use strict';

/** REST routes for student records: list, read, create, update, delete. */

const express = require('express');
const { validateStudent, readListOptions } = require('../validators');

/** Columns the table may be sorted by (query value -> SQL expression). */
const SORTABLE = {
  student_no: 'student_no',
  last_name: 'last_name COLLATE NOCASE',
  programme: 'programme',
  year: 'year',
  status: 'status'
};

/** Turn a database row into the JSON shape the interface expects. */
function toJson(row) {
  return { ...row, access_arrangements: JSON.parse(row.access_arrangements) };
}

module.exports = function studentRoutes(db) {
  const router = express.Router();

  // GET /api/students?q=&programme=&status=&sort=&order=&page=&pageSize=
  router.get('/', (req, res) => {
    const { page, pageSize, sort, order } = readListOptions(req.query, SORTABLE, 'last_name');
    const where = [];
    const params = {};

    if (req.query.q) {
      where.push(`(student_no LIKE @q OR first_name LIKE @q OR last_name LIKE @q
                   OR email LIKE @q OR first_name || ' ' || last_name LIKE @q)`);
      params.q = `%${String(req.query.q).trim()}%`;
    }
    if (req.query.programme) {
      where.push('programme = @programme');
      params.programme = String(req.query.programme);
    }
    if (req.query.status) {
      where.push('status = @status');
      params.status = String(req.query.status);
    }

    const whereSql = where.length ? `WHERE ${where.join(' AND ')}` : '';
    const { total } = db.prepare(`SELECT COUNT(*) AS total FROM students ${whereSql}`).get(params);

    // If the last row on a page was deleted, fall back to the new last page.
    const lastPage = Math.max(1, Math.ceil(total / pageSize));
    const currentPage = Math.min(page, lastPage);

    const rows = db.prepare(`
      SELECT * FROM students ${whereSql}
      ORDER BY ${SORTABLE[sort]} ${order}, first_name ASC, id ASC
      LIMIT @limit OFFSET @offset
    `).all({ ...params, limit: pageSize, offset: (currentPage - 1) * pageSize });

    res.json({ rows: rows.map(toJson), total, page: currentPage, pageSize });
  });

  // GET /api/students/by-number/S240123 - used by the marks form look-up
  router.get('/by-number/:studentNo', (req, res) => {
    const row = db.prepare('SELECT * FROM students WHERE student_no = ?')
      .get(req.params.studentNo.toUpperCase());
    if (!row) {
      return res.json({ ok: false, notFound: true, error: `No student found with number ${req.params.studentNo}.` });
    }
    return res.json(toJson(row));
  });

  router.get('/:id', (req, res) => {
    const row = db.prepare('SELECT * FROM students WHERE id = ?').get(req.params.id);
    if (!row) {
      return res.status(404).json({ error: 'This student record no longer exists.' });
    }
    return res.json(toJson(row));
  });

  /**
   * Shared by create and update. `id` is null when creating.
   *
   * A form that fails validation is an expected, everyday outcome, so it is
   * answered with HTTP 200 and { ok: false, fields } rather than a 4xx code.
   * (Browsers log every 4xx response as a console error.) Real failures,
   * such as a record that no longer exists, still use 404/500.
   */
  function save(req, res, id) {
    const { errors, value } = validateStudent(req.body || {});

    const duplicate = db.prepare('SELECT id FROM students WHERE student_no = ?').get(value.student_no);
    if (duplicate && duplicate.id !== id) {
      errors.student_no = `Student number ${value.student_no} is already used by another record.`;
    }
    if (Object.keys(errors).length) {
      return res.json({ ok: false, error: 'Some fields need correcting.', fields: errors });
    }

    const record = {
      ...value,
      access_arrangements: JSON.stringify(value.access_arrangements),
      updated_at: new Date().toISOString()
    };

    if (id === null) {
      const result = db.prepare(`
        INSERT INTO students (student_no, first_name, last_name, email, programme, year, mode,
                              status, access_arrangements, access_notes, updated_at)
        VALUES (@student_no, @first_name, @last_name, @email, @programme, @year, @mode,
                @status, @access_arrangements, @access_notes, @updated_at)
      `).run(record);
      return res.status(201).json({ id: result.lastInsertRowid, ...value });
    }

    const result = db.prepare(`
      UPDATE students SET student_no = @student_no, first_name = @first_name,
        last_name = @last_name, email = @email, programme = @programme, year = @year,
        mode = @mode, status = @status, access_arrangements = @access_arrangements,
        access_notes = @access_notes, updated_at = @updated_at
      WHERE id = @id
    `).run({ ...record, id });
    if (result.changes === 0) {
      return res.status(404).json({ error: 'This student record no longer exists.' });
    }
    return res.json({ id, ...value });
  }

  router.post('/', (req, res) => save(req, res, null));
  router.put('/:id', (req, res) => save(req, res, Number(req.params.id)));

  router.delete('/:id', (req, res) => {
    const result = db.prepare('DELETE FROM students WHERE id = ?').run(req.params.id);
    if (result.changes === 0) {
      return res.status(404).json({ error: 'This student record no longer exists.' });
    }
    return res.status(204).end();
  });

  return router;
};
