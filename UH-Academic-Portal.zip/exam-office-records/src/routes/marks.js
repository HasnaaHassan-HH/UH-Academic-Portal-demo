'use strict';

/** REST routes for exam marks: list, read, create, update, delete. */

const express = require('express');
const { validateMark, readListOptions } = require('../validators');
const { calculateFinalMark } = require('../db');
const { PASS_MARK } = require('../reference');

const SORTABLE = {
  student: 's.last_name COLLATE NOCASE',
  module: 'a.module_code',
  final_mark: 'm.final_mark',
  updated_at: 'm.updated_at'
};

/** Every query that returns marks joins the same three tables. */
const SELECT_MARK = `
  SELECT m.id, m.attempt, m.outcome, m.mark, m.late_days, m.final_mark, m.absence_reason,
         m.moderated, m.comment, m.entered_by, m.updated_at, m.assessment_id,
         s.student_no, s.first_name, s.last_name,
         a.title AS assessment_title, a.module_code
  FROM marks m
  JOIN students s ON s.id = m.student_id
  JOIN assessments a ON a.id = m.assessment_id
`;

module.exports = function markRoutes(db) {
  const router = express.Router();

  // GET /api/marks?q=&module=&result=&sort=&order=&page=&pageSize=
  router.get('/', (req, res) => {
    const { page, pageSize, sort, order } = readListOptions(req.query, SORTABLE, 'updated_at');
    const where = [];
    const params = {};

    if (req.query.q) {
      where.push(`(s.student_no LIKE @q OR s.first_name LIKE @q OR s.last_name LIKE @q
                   OR s.first_name || ' ' || s.last_name LIKE @q)`);
      params.q = `%${String(req.query.q).trim()}%`;
    }
    if (req.query.module) {
      where.push('a.module_code = @module');
      params.module = String(req.query.module);
    }
    // "result" filter: pass, fail, absent or deferred
    if (req.query.result === 'pass') {
      where.push(`m.outcome = 'submitted' AND m.final_mark >= ${PASS_MARK}`);
    } else if (req.query.result === 'fail') {
      where.push(`m.outcome = 'submitted' AND m.final_mark < ${PASS_MARK}`);
    } else if (req.query.result === 'absent' || req.query.result === 'deferred') {
      where.push('m.outcome = @outcome');
      params.outcome = req.query.result;
    }

    const whereSql = where.length ? `WHERE ${where.join(' AND ')}` : '';
    const { total } = db.prepare(`
      SELECT COUNT(*) AS total FROM marks m
      JOIN students s ON s.id = m.student_id
      JOIN assessments a ON a.id = m.assessment_id ${whereSql}
    `).get(params);

    const lastPage = Math.max(1, Math.ceil(total / pageSize));
    const currentPage = Math.min(page, lastPage);

    const rows = db.prepare(`
      ${SELECT_MARK} ${whereSql}
      ORDER BY ${SORTABLE[sort]} ${order}, m.id DESC
      LIMIT @limit OFFSET @offset
    `).all({ ...params, limit: pageSize, offset: (currentPage - 1) * pageSize });

    res.json({ rows, total, page: currentPage, pageSize });
  });

  router.get('/:id', (req, res) => {
    const row = db.prepare(`${SELECT_MARK} WHERE m.id = ?`).get(req.params.id);
    if (!row) {
      return res.status(404).json({ error: 'This mark no longer exists.' });
    }
    return res.json(row);
  });

  /**
   * Shared by create and update. `id` is null when creating.
   *
   * A form that fails validation is an expected, everyday outcome, so it is
   * answered with HTTP 200 and { ok: false, fields } rather than a 4xx code.
   * (Browsers log every 4xx response as a console error.) Real failures,
   * such as a record that no longer exists, still use 404/500.
   */
  function save(req, res, id) {
    const { errors, value } = validateMark(req.body || {});

    const student = db.prepare('SELECT id, first_name, last_name FROM students WHERE student_no = ?')
      .get(value.student_no);
    if (!errors.student_no && !student) {
      errors.student_no = `No student found with number ${value.student_no}. Check the number and try again.`;
    }
    const assessment = db.prepare('SELECT id FROM assessments WHERE id = ?').get(value.assessment_id);
    if (!errors.assessment_id && !assessment) {
      errors.assessment_id = 'Select an assessment.';
    }
    if (Object.keys(errors).length) {
      return res.json({ ok: false, error: 'Some fields need correcting.', fields: errors });
    }

    // One mark per student, assessment and attempt: stop accidental double entry.
    const existing = db.prepare(`
      SELECT id FROM marks WHERE student_id = ? AND assessment_id = ? AND attempt = ?
    `).get(student.id, value.assessment_id, value.attempt);
    if (existing && existing.id !== id) {
      return res.json({
        ok: false,
        error: 'Some fields need correcting.',
        fields: {
          student_no: `A ${value.attempt === 'first' ? 'first attempt' : 'resit'} mark is already recorded for `
            + `${student.first_name} ${student.last_name} on this assessment. Edit the existing mark instead.`
        },
        existingId: existing.id
      });
    }

    const record = {
      student_id: student.id,
      assessment_id: value.assessment_id,
      attempt: value.attempt,
      outcome: value.outcome,
      mark: value.mark,
      late_days: value.late_days,
      final_mark: calculateFinalMark(value.outcome, value.mark, value.late_days),
      absence_reason: value.absence_reason,
      moderated: value.moderated,
      comment: value.comment,
      entered_by: value.entered_by,
      updated_at: new Date().toISOString()
    };

    let savedId = id;
    if (id === null) {
      savedId = db.prepare(`
        INSERT INTO marks (student_id, assessment_id, attempt, outcome, mark, late_days, final_mark,
                           absence_reason, moderated, comment, entered_by, updated_at)
        VALUES (@student_id, @assessment_id, @attempt, @outcome, @mark, @late_days, @final_mark,
                @absence_reason, @moderated, @comment, @entered_by, @updated_at)
      `).run(record).lastInsertRowid;
    } else {
      const result = db.prepare(`
        UPDATE marks SET student_id = @student_id, assessment_id = @assessment_id,
          attempt = @attempt, outcome = @outcome, mark = @mark, late_days = @late_days,
          final_mark = @final_mark, absence_reason = @absence_reason, moderated = @moderated,
          comment = @comment, entered_by = @entered_by, updated_at = @updated_at
        WHERE id = @id
      `).run({ ...record, id });
      if (result.changes === 0) {
        return res.status(404).json({ error: 'This mark no longer exists.' });
      }
    }

    const saved = db.prepare(`${SELECT_MARK} WHERE m.id = ?`).get(savedId);
    return res.status(id === null ? 201 : 200).json(saved);
  }

  router.post('/', (req, res) => save(req, res, null));
  router.put('/:id', (req, res) => save(req, res, Number(req.params.id)));

  router.delete('/:id', (req, res) => {
    const result = db.prepare('DELETE FROM marks WHERE id = ?').run(req.params.id);
    if (result.changes === 0) {
      return res.status(404).json({ error: 'This mark no longer exists.' });
    }
    return res.status(204).end();
  });

  return router;
};
