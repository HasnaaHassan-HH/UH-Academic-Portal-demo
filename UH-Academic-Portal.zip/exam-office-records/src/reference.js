'use strict';

/**
 * Reference data shared by the database seed, the validators and the API.
 * Keeping the allowed values in one place means the server and the
 * drop-down lists in the interface can never drift apart.
 */

const PROGRAMMES = [
  'BSc Computer Science',
  'BSc Software Engineering',
  'BSc Data Science',
  'BSc Cyber Security'
];

const STUDY_MODES = ['full-time', 'part-time'];

const STUDENT_STATUSES = ['active', 'interrupted', 'withdrawn'];

const ACCESS_ARRANGEMENTS = [
  { value: 'extra-time', label: '25% extra time' },
  { value: 'separate-room', label: 'Separate room' },
  { value: 'computer', label: 'Use of a computer' },
  { value: 'rest-breaks', label: 'Supervised rest breaks' }
];

const ATTEMPTS = ['first', 'resit'];

const OUTCOMES = ['submitted', 'absent', 'deferred'];

const ABSENCE_REASONS = [
  { value: 'unauthorised', label: 'Unauthorised absence' },
  { value: 'medical', label: 'Medical evidence provided' },
  { value: 'other', label: 'Other reason' }
];

/** Marks at or above this value pass. Late work is capped at this value. */
const PASS_MARK = 40;

/** Latest a piece of work can be handed in and still be marked. */
const MAX_LATE_DAYS = 5;

const MODULES = [
  { code: 'CS101', title: 'Programming Fundamentals', assessments: ['Coursework', 'Written exam'] },
  { code: 'CS205', title: 'Database Systems', assessments: ['Practical project', 'Written exam'] },
  { code: 'CS240', title: 'Accessibility and Usability', assessments: ['Coursework 1', 'Coursework 2'] },
  { code: 'MA110', title: 'Discrete Mathematics', assessments: ['Class test', 'Written exam'] },
  { code: 'BM150', title: 'Professional Practice', assessments: ['Portfolio', 'Presentation'] }
];

module.exports = {
  PROGRAMMES,
  STUDY_MODES,
  STUDENT_STATUSES,
  ACCESS_ARRANGEMENTS,
  ATTEMPTS,
  OUTCOMES,
  ABSENCE_REASONS,
  PASS_MARK,
  MAX_LATE_DAYS,
  MODULES
};
