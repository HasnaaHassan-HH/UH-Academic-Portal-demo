# Manual test checklist (keyboard and NVDA)

Do this on the **live site** and write down what really happens: your report
must describe your own testing. Allow about 30 minutes.

Setup: Windows, Chrome or Firefox, NVDA (free from nvaccess.org).
NVDA basics: `Ctrl` stops speech, `Insert+F7` lists headings/links/landmarks,
`H` next heading, `D` next landmark, `T` next table, `F` next form field,
`Ctrl+Alt+arrow keys` move between table cells, `Insert+Q` quits NVDA.

For each step note: **Pass / Problem**, and exactly what NVDA said.

## Part 1: keyboard only (NVDA off, do not touch the mouse)

1. Sign-in page: press `Tab` once. Does "Skip to main content" appear?
2. Submit the empty form with `Enter`. Does focus jump to "There is a problem"?
   Does `Enter` on an error link move you to that field?
3. Sign in (`officer` / `exams2026`). Tab through the header: is the focus
   ring always visible, including on the dark header?
4. Students: type in Search, change both filters, press each column header
   with `Enter`, use Next / Previous. Can you do everything? Does focus stay
   where you were?
5. Press Delete on a row, then `Esc`. Does focus go back to the same Delete?
   Open it again: does `Tab` stay inside the dialog?
6. Enter marks: complete the form and use "Save and enter next" three times
   without the mouse. Does focus return to Student number each time?
7. Zoom the browser to 200% (`Ctrl` and `+`), then 400%. Anything cut off or
   needing sideways scrolling?

## Part 2: NVDA on

8. Each page: `Insert+F7` > Headings. Is there one level 1 heading and a
   sensible outline? > Landmarks: banner, navigation, main, content info?
9. Sign in with a wrong password. Is "Signing in" announced? Is the error read?
10. Students: type a name in Search. Is "Showing 1 to N of N students" read
    out? Search for `zzzz`: is "No students found" read?
11. Press `T` to reach the table, move with `Ctrl+Alt+arrows`. Are the column
    header and the student's name read with each cell? Press a sort button:
    is "sorted ascending/descending" announced?
12. Enter marks: tab through. Is every label, hint and "required" read?
    Type a student number and tab away: is the student's name announced?
13. Choose Absent: is the new "Reason for absence" field the next thing you
    reach? Tick "Submitted late": do you reach "Days late" next?
14. Save with errors: are the summary and then each field's error read?
15. Save a correct mark: is "Mark saved for ..." announced?
16. Delete a mark: is the dialog title read? After confirming, is the
    "Deleted ..." message read?

## Part 3: automated scan on the live site

17. Install the **axe DevTools** extension, open DevTools > axe DevTools >
    "Scan all of my page" on each of the 6 pages. Screenshot each result.
18. Optionally repeat with WAVE (wave.webaim.org) for a second opinion.

Put the screenshots and your notes into the evaluation report.
